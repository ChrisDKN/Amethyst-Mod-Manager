using System.Text.Json;
using System.Diagnostics;
using System.Windows.Forms;
using FomodInstaller.Interface;
using FomodInstaller.Interface.ui;
using FomodInstaller.Scripting.CSharpScript;
using OMODFramework;
using OMODFramework.Scripting;
using FormsResult = System.Windows.Forms.DialogResult;
using OmodResult = OMODFramework.Scripting.DialogResult;

namespace Amethyst.LegacyInstaller;

static class Program
{
    static readonly object RpcLock = new();
    static JsonElement Request;
    static readonly List<object> IniEdits = new();
    internal static readonly Dictionary<string, bool> Activations = new(StringComparer.OrdinalIgnoreCase);
    static string Output = "";
    static string? ScriptError;
    static readonly Dictionary<bool, string[]> PluginLists = new();

    public static JsonElement Call(string op, object? args = null)
    {
        lock (RpcLock)
        {
            Console.WriteLine(JsonSerializer.Serialize(new { op, args }));
            Console.Out.Flush();
            var line = Console.ReadLine() ?? throw new IOException("Amethyst disconnected.");
            var reply = JsonSerializer.Deserialize<JsonElement>(line);
            if (reply.TryGetProperty("error", out var error))
                throw new IOException(error.GetString());
            return reply.GetProperty("result").Clone();
        }
    }

    static string SafePath(string root, string relative)
    {
        relative = relative.Replace('\\', '/');
        if (relative.Length == 0 || relative.Split('/').Any(p => p is "" or "." or "..")
            || relative.Contains(':') || relative.Any(char.IsControl))
            throw new IOException("Unsafe installer path: " + relative);
        var full = Path.GetFullPath(Path.Combine(root, relative));
        if (!full.StartsWith(Path.GetFullPath(root) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            throw new IOException("Installer path escapes its output folder.");
        return full;
    }

    static void Copy(string root, string source, string destination)
    {
        var target = SafePath(Output, destination);
        Directory.CreateDirectory(Path.GetDirectoryName(target)!);
        File.Copy(SafePath(root, source), target, true);
    }

    static IEnumerable<string> InputFiles(string root, string excluded)
    {
        var pending = new Stack<string>();
        pending.Push(root);
        while (pending.TryPop(out var folder))
            foreach (var path in Directory.EnumerateFileSystemEntries(folder))
            {
                if ((Path.GetFullPath(path) + Path.DirectorySeparatorChar).StartsWith(excluded, StringComparison.OrdinalIgnoreCase))
                    continue;
                var attributes = File.GetAttributes(path);
                if ((attributes & FileAttributes.ReparsePoint) != 0)
                    throw new IOException("Legacy installer input cannot contain links.");
                if ((attributes & FileAttributes.Directory) != 0) pending.Push(path);
                else yield return Path.GetRelativePath(root, path);
            }
    }

    static Version VersionFor(string name) => new(Call("version", new { name }).GetString() ?? "0.0.0.0");
    static string ReadIni(string file, string section, string key) => Call("ini", new { file, section, key }).GetString() ?? "";
    static string[] Plugins(bool active)
    {
        if (!PluginLists.TryGetValue(active, out var plugins))
            PluginLists[active] = plugins = Call("plugins", new { active }).Deserialize<string[]>()!;
        return plugins;
    }
    static byte[] Existing(string path) => Convert.FromBase64String(Call("read", new { path }).GetString()!);
    static bool Exists(string path) => Call("exists", new { path }).GetBoolean();

    [STAThread]
    static int Main(string[] args)
    {
        try
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Request = JsonSerializer.Deserialize<JsonElement>(File.ReadAllText(args[0]));
            Output = Request.GetProperty("output").GetString()!;
            Directory.CreateDirectory(Output);
            if (Request.GetProperty("kind").GetString() == "omod") RunOmod();
            else RunFomod();
            if (IniEdits.Count != 0)
            {
                var changes = IniEdits.Select(edit => JsonSerializer.SerializeToElement(edit))
                    .Select(edit => $"{edit.GetProperty("file").GetString()}: [{edit.GetProperty("section").GetString()}] {edit.GetProperty("key").GetString()}={edit.GetProperty("value").GetString()}");
                if (MessageBox.Show("Apply these game INI changes?\n\n" + string.Join("\n", changes),
                        "Legacy installer settings", MessageBoxButtons.OKCancel, MessageBoxIcon.Question,
                        MessageBoxDefaultButton.Button2) != FormsResult.OK)
                    throw new OperationCanceledException("Game INI changes cancelled.");
            }
            File.WriteAllText(Request.GetProperty("result").GetString()!, JsonSerializer.Serialize(new {
                version = 1, ini = IniEdits, plugins = Activations, settings_confirmed = true
            }));
            return 0;
        }
        catch (OperationCanceledException)
        {
            return 2;
        }
        catch (Exception error)
        {
            Console.Error.WriteLine(error);
            return 1;
        }
    }

    static void RunFomod()
    {
        var root = Request.GetProperty("source").GetString()!;
        var scriptPath = Request.GetProperty("script").GetString()!;
        if (!scriptPath.EndsWith(".cs", StringComparison.OrdinalIgnoreCase))
            throw new NotSupportedException("Compiled script.dll installers are not supported.");
        var work = Path.GetDirectoryName(Output)! + Path.DirectorySeparatorChar;
        var files = InputFiles(root, work).ToList();
        var type = new CSharpScriptType();
        var mod = new Mod(files, new List<string>(), Path.GetRelativePath(root, scriptPath), root, type);
        mod.Initialize(false).GetAwaiter().GetResult();
        var executor = new CSharpScriptExecutor(new CSharpScriptFunctionProxy(mod, new Core()), typeof(CompatBaseScript));
        var instructions = executor.Execute(new CSharpScript(type, File.ReadAllText(scriptPath)), root, null).GetAwaiter().GetResult();
        if (ScriptError != null) throw new IOException(ScriptError);
        if (instructions == null) throw new OperationCanceledException("Installer cancelled or failed.");
        var enableAll = false;
        foreach (var instruction in instructions.OrderBy(i => i.priority))
        {
            switch (instruction.type)
            {
                case "copy": Copy(root, instruction.source, instruction.destination); break;
                case "generatefile":
                    var target = SafePath(Output, instruction.destination);
                    Directory.CreateDirectory(Path.GetDirectoryName(target)!);
                    File.WriteAllBytes(target, instruction.data);
                    break;
                case "mkdir": Directory.CreateDirectory(SafePath(Output, instruction.destination)); break;
                case "iniedit":
                    IniEdits.Add(new { file = instruction.destination, section = instruction.section, key = instruction.key, value = instruction.value });
                    break;
                case "enableplugin": Activations[instruction.source] = true; break;
                case "enableallplugins": enableAll = true; break;
                default: throw new NotSupportedException($"Installer instruction {instruction.type}: {instruction.source}");
            }
        }
        if (enableAll)
            foreach (var file in Directory.EnumerateFiles(Output, "*", SearchOption.AllDirectories))
                if (new[] { ".esp", ".esm", ".esl" }.Contains(Path.GetExtension(file), StringComparer.OrdinalIgnoreCase))
                    Activations.TryAdd(Path.GetFileName(file), true);
    }

    static string ChooseOmod(JsonElement packages)
    {
        using var form = new Form { Text = "Choose OMOD package", Width = 1000, Height = 400, StartPosition = FormStartPosition.CenterScreen };
        var heading = new Label { Text = "This archive contains multiple OMOD packages. Choose one to install.", Dock = DockStyle.Top, Height = 40 };
        var list = new ListBox { Dock = DockStyle.Fill, HorizontalScrollbar = true };
        list.Items.AddRange(packages.EnumerateArray().Select(p => p.GetProperty("label").GetString()!).ToArray());
        var install = new Button { Text = "Install", DialogResult = FormsResult.OK, Enabled = false };
        var cancel = new Button { Text = "Cancel", DialogResult = FormsResult.Cancel };
        var buttons = new FlowLayoutPanel { Dock = DockStyle.Bottom, AutoSize = true, FlowDirection = FlowDirection.RightToLeft };
        buttons.Controls.Add(cancel); buttons.Controls.Add(install);
        list.SelectedIndexChanged += (_, _) => install.Enabled = list.SelectedIndex >= 0;
        form.Controls.Add(list); form.Controls.Add(heading); form.Controls.Add(buttons);
        form.AcceptButton = install; form.CancelButton = cancel;
        if (form.ShowDialog() != FormsResult.OK) throw new OperationCanceledException();
        return packages[list.SelectedIndex].GetProperty("source").GetString()!;
    }

    static void RunOmod()
    {
        var source = Request.TryGetProperty("packages", out var packages) ? ChooseOmod(packages)
            : Request.GetProperty("source").GetString()!;
        Console.Error.WriteLine($"Legacy package: {Path.GetFileName(source)}");
        using var omod = new OMOD(source);
        var work = Request.GetProperty("work").GetString()!;
        var scripted = omod.HasEntryFile(OMODEntryFileType.Script);
        var dataFolder = scripted ? Path.Combine(work, "data") : Output;
        var pluginsFolder = scripted ? Path.Combine(work, "plugins") : Output;
        var data = omod.GetDataFiles();
        var bytes = data.Sum(file => file.Length);
        var budget = Request.GetProperty("memory_budget").GetInt64();
        if (bytes > budget)
            throw new IOException($"This OMOD needs {bytes / (1024 * 1024)} MiB of extraction memory; the current budget is {budget / (1024 * 1024)} MiB.");
        foreach (var file in data) SafePath(dataFolder, file.Name);
        if (omod.HasEntryFile(OMODEntryFileType.PluginsCRC))
        {
            var plugins = omod.GetPluginFiles();
            if (plugins.Sum(file => file.Length) > budget)
                throw new IOException("The OMOD plugins exceed the extraction memory budget.");
            foreach (var file in plugins) SafePath(pluginsFolder, file.Name);
        }
        var timer = Stopwatch.StartNew();
        var workers = Math.Clamp(Environment.ProcessorCount, 1, 4);
        if (data.Count >= 64 && data.All(file => file.Length > 0) && bytes >= 32 * 1024 * 1024 && workers > 1)
            omod.ExtractFilesParallel(dataFolder, (byte)workers, workers, verify: true);
        else
            omod.ExtractFiles(true, dataFolder, verify: true);
        if (omod.HasEntryFile(OMODEntryFileType.PluginsCRC))
            omod.ExtractFiles(false, pluginsFolder, verify: true);
        Console.Error.WriteLine($"Legacy timing: OMOD extraction {timer.Elapsed.TotalSeconds:F2}s ({workers} worker limit).");
        if (!scripted) return;
        var result = OMODScriptRunner.RunScript(omod, new OMODScriptSettings(new OmodExternal()) { DryRun = true }, work);
        if (result.RegisteredBSAs.Count != 0 || result.UnregisteredBSAs.Count != 0
            || result.SDPEdits.Count != 0 || result.PluginEdits.Count != 0
            || result.SetPluginInfos.Count != 0 || result.FilePatches.Count != 0)
            throw new NotSupportedException("This OMOD requests unsupported BSA, shader, plugin or binary edits.");
        timer.Restart();
        foreach (var file in result.DataFiles) Copy(result.DataFolder, file.Input.Name, file.Output);
        foreach (var file in result.PluginFiles)
        {
            if (file.LoadEarly || file.LoadBefore.Count != 0 || file.LoadAfter.Count != 0)
                throw new NotSupportedException("OMOD load order changes are not supported.");
            Copy(result.PluginsFolder, file.Input.Name, file.Output);
            Activations[file.Output] = !file.IsUnchecked;
        }
        foreach (var edit in result.EditXMLInfos)
        {
            var target = SafePath(Output, edit.File.Output);
            if (!File.Exists(target)) Copy(result.DataFolder, edit.File.Input.Name, edit.File.Output);
            if (edit.IsReplace)
                File.WriteAllText(target, File.ReadAllText(target).Replace(edit.Find, edit.Replace));
            else
            {
                var lines = File.ReadAllLines(target);
                if (edit.Line < 0 || edit.Line >= lines.Length) throw new IOException("Invalid XML edit line.");
                lines[edit.Line] = edit.Value;
                File.WriteAllLines(target, lines);
            }
        }
        foreach (var edit in result.INIEdits)
            IniEdits.Add(new { file = "Oblivion.ini", section = edit.Section.Trim('[', ']'), key = edit.Name, value = edit.NewValue });
        Console.Error.WriteLine($"Legacy timing: OMOD output copying and edits {timer.Elapsed.TotalSeconds:F2}s.");
    }

    sealed class Core : CoreDelegates
    {
        public override PluginDelegates plugin { get; } = new PluginContext();
        public override IniDelegates ini { get; } = new IniContext();
        public override ContextDelegates context { get; } = new GameContext();
        public override UIDelegates ui { get; } = new UiContext();
    }

    sealed class PluginContext : PluginDelegates
    {
        public override string[] GetAll(bool activeOnly) => Plugins(activeOnly);
        public override bool IsActive(string name) => Plugins(true).Contains(name, StringComparer.OrdinalIgnoreCase);
        public override bool IsPresent(string name) => Plugins(false).Contains(name, StringComparer.OrdinalIgnoreCase);
    }

    sealed class IniContext : IniDelegates
    {
        public override Task<string> GetIniString(string file, string section, string key) => Task.FromResult(ReadIni(file, section, key));
        public override Task<int> GetIniInt(string file, string section, string key) => Task.FromResult(int.TryParse(ReadIni(file, section, key), out var value) ? value : 0);
    }

    sealed class GameContext : ContextDelegates
    {
        public override string GetAppVersion() => "1.0.0.0";
        public override string GetCurrentGameVersion() => VersionFor("game").ToString();
        public override string GetExtenderVersion(string extender) => VersionFor(extender).ToString();
        public override Task<bool> IsExtenderPresent() => Task.FromResult(Call("extender").GetBoolean());
        public override Task<bool> CheckIfFileExists(string file) => Task.FromResult(Exists(file));
        public override Task<byte[]> GetExistingDataFile(string file) => Task.FromResult(Exists(file) ? Existing(file) : null!);
        public override Task<string[]> GetExistingDataFileList(string path, string pattern, bool recursive) =>
            Task.FromResult(Call("list", new { path, pattern, recursive }).Deserialize<string[]>()!);
    }

    sealed class UiContext : UIDelegates
    {
        public override void StartDialog(string name, HeaderImage image, Action<int, int, int[]> select, Action<bool, int> cont, Action cancel) => throw new NotSupportedException();
        public override void EndDialog() { }
        public override void UpdateState(InstallerStep[] steps, int current) => throw new NotSupportedException();
        public override void ReportError(string title, string message, string details)
        {
            ScriptError = $"{title}: {message}\n{details}";
            Console.Error.WriteLine(ScriptError);
        }
    }

    internal static int[] Select(string[] items, Image[]? previews, string[]? descriptions, string title, bool many)
    {
        var bitmaps = previews?.Select(image => image == null ? null! : new Bitmap(image)).ToArray() ?? Array.Empty<Bitmap>();
        try { return new OmodExternal().Select(items, title, many, bitmaps, descriptions ?? Array.Empty<string>()).ToArray(); }
        finally { foreach (var image in bitmaps) image?.Dispose(); }
    }

    sealed class OmodExternal : IExternalScriptFunctions
    {
        public void Message(string message) => Message(message, "OMOD installer");
        public void Message(string message, string title) => MessageBox.Show(message, title);
        public string InputString(string? title, string? initial)
        {
            using var form = new Form { Text = title ?? "OMOD installer", Width = 480, Height = 150, StartPosition = FormStartPosition.CenterScreen };
            var text = new TextBox { Text = initial ?? "", Dock = DockStyle.Top };
            var ok = new Button { Text = "OK", DialogResult = FormsResult.OK, Dock = DockStyle.Bottom };
            form.Controls.Add(text); form.Controls.Add(ok); form.AcceptButton = ok;
            if (form.ShowDialog() != FormsResult.OK) throw new OperationCanceledException();
            return text.Text;
        }
        public OmodResult DialogYesNo(string message) => DialogYesNo(message, "OMOD installer");
        public OmodResult DialogYesNo(string message, string title) => MessageBox.Show(message, title, MessageBoxButtons.YesNoCancel) switch {
            FormsResult.Yes => OmodResult.Yes, FormsResult.No => OmodResult.No, _ => throw new OperationCanceledException()
        };
        public void DisplayText(string text, string? title) => Message(text, title ?? "OMOD installer");
        public void DisplayImage(string path, string? title) { using var image = new Bitmap(path); DisplayImage(image, title); }
        public void DisplayImage(Bitmap image, string? title)
        {
            using var form = new Form { Text = title ?? "OMOD installer", Width = 900, Height = 650 };
            form.Controls.Add(new PictureBox { Image = image, Dock = DockStyle.Fill, SizeMode = PictureBoxSizeMode.Zoom });
            form.ShowDialog();
        }
        public IEnumerable<int> Select(IEnumerable<string> items, string title, bool many, IEnumerable<string> previews, IEnumerable<string> descriptions)
        {
            var images = new List<Bitmap>();
            try
            {
                foreach (var path in previews)
                    images.Add(string.IsNullOrEmpty(path) ? null! : new Bitmap(path));
                return Select(items, title, many, images, descriptions).ToArray();
            }
            finally { foreach (var image in images) image?.Dispose(); }
        }
        public IEnumerable<int> Select(IEnumerable<string> items, string title, bool many, IEnumerable<Bitmap> previews, IEnumerable<string> descriptions)
        {
            using var form = new Form { Text = title, Width = 900, Height = 650, StartPosition = FormStartPosition.CenterScreen };
            var list = new ListBox { Dock = DockStyle.Left, Width = 320, SelectionMode = many ? SelectionMode.MultiExtended : SelectionMode.One };
            var picture = new PictureBox { Dock = DockStyle.Fill, SizeMode = PictureBoxSizeMode.Zoom };
            var description = new TextBox { Dock = DockStyle.Bottom, Height = 150, Multiline = true, ReadOnly = true };
            var labels = items.ToArray(); var images = previews.ToArray(); var texts = descriptions.ToArray();
            list.Items.AddRange(labels.Select(s => s.TrimStart('|')).ToArray());
            list.SelectedIndexChanged += (_, _) => {
                var i = list.SelectedIndex;
                picture.Image = i >= 0 && i < images.Length ? images[i] : null;
                description.Text = i >= 0 && i < texts.Length ? texts[i] : "";
            };
            for (var i = 0; i < labels.Length; i++) if (labels[i].StartsWith('|')) list.SetSelected(i, true);
            var ok = new Button { Text = "OK", Dock = DockStyle.Bottom, DialogResult = FormsResult.OK };
            form.Controls.Add(picture); form.Controls.Add(description); form.Controls.Add(list); form.Controls.Add(ok);
            if (form.ShowDialog() != FormsResult.OK) throw new OperationCanceledException();
            return list.SelectedIndices.Cast<int>().ToArray();
        }
        public bool HasScriptExtender() => Call("extender").GetBoolean();
        public bool HasGraphicsExtender() => Exists("obse/plugins/obge.dll");
        public Version GetScriptExtenderVersion() => VersionFor("obse");
        public Version GetGraphicsExtenderVersion() => VersionFor("obge");
        public Version GetOblivionVersion() => VersionFor("game");
        public Version GetOBSEPluginVersion(string file) => VersionFor("obse/plugins/" + file + ".dll");
        public IEnumerable<Plugin> GetPlugins()
        {
            var active = Plugins(true).ToHashSet(StringComparer.OrdinalIgnoreCase);
            return Plugins(false).Select(name => new Plugin(name) { Active = active.Contains(name) }).ToArray();
        }
        public IEnumerable<string> GetActiveOMODNames() => Call("mods").Deserialize<string[]>()!;
        public byte[] ReadExistingDataFile(string file) => Existing(file);
        public bool DataFileExists(string path) => Exists(path);
        public string ReadINI(string section, string key) => ReadIni("Oblivion.ini", section.Trim('[', ']'), key);
        public string ReadRendererInfo(string key) => throw new NotSupportedException("Renderer information is unavailable.");
        public void SetNewLoadOrder(string[] plugins) => throw new NotSupportedException("OMOD load order changes are not supported.");
        public byte[] GetDataFileFromBSA(string file) => throw new NotSupportedException("Unqualified BSA reads are not supported.");
        public byte[] GetDataFileFromBSA(string bsa, string file) => throw new NotSupportedException("BSA reads are not supported.");
        public string GetExistingBSAPath(string bsa) => Call("bsa", new { path = bsa }).GetString()!;
    }
}

public class CompatBaseScript : CSharpBaseScript
{
    public new static void SetPluginActivation(string plugin, bool enabled) => Program.Activations[plugin] = enabled;
    public new static bool GenerateDataFile(string path, byte[] data)
    {
        Functions.GenerateDataFile(path, data);
        return true;
    }
    public new static void SetPluginOrderIndex(string plugin, int index) => throw new NotSupportedException("Scripted load order changes are not supported.");
    public new static void SetLoadOrder(int[] plugins) => throw new NotSupportedException("Scripted load order changes are not supported.");
    public new static void SetLoadOrder(int[] plugins, int position) => throw new NotSupportedException("Scripted load order changes are not supported.");
    public new static int[] Select(SelectOption[] options, string title, bool many) =>
        Select(options.Select(option => option.Item).ToArray(), options.Select(option => option.Preview).ToArray(), options.Select(option => option.Desc).ToArray(), title, many);
    public new static int[] Select(string[] items, string[] previews, string[] descriptions, string title, bool many)
    {
        var images = new List<Image>();
        try
        {
            foreach (var path in previews ?? Array.Empty<string>())
            {
                if (string.IsNullOrEmpty(path)) { images.Add(null!); continue; }
                using var stream = new MemoryStream(GetFileFromMod(path));
                using var image = Image.FromStream(stream);
                images.Add(new Bitmap(image));
            }
            return Program.Select(items, images.ToArray(), descriptions, title, many);
        }
        finally { foreach (var image in images) image?.Dispose(); }
    }
    public new static int[] ImageSelect(string[] items, Image[] previews, string[] descriptions, string title, bool many) =>
        Program.Select(items, previews, descriptions, title, many);
}
