#!/usr/bin/env python3
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

from release import create_release, collect_notices, file_hash


ROOT = Path(__file__).resolve().parent
SOURCES = {
    "fomod": ("https://github.com/Nexus-Mods/fomod-installer.git", "af3c8355b2e22f1c7c4272c8eb3cb928ccb5f8c1"),
    "omod": ("https://github.com/erri120/OMODFramework.git", "d41af056d268e621f2a03c4191cc6f3958077ed3"),
}


def source_tree(name, url, revision):
    path = ROOT / ".build" / name
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(["git", "clone", url, str(path)], check=True)
        subprocess.run(["git", "checkout", "--detach", revision], cwd=path, check=True)
    if (path / ".git").exists():
        actual = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=path, text=True).strip()
        if actual != revision:
            raise RuntimeError(f"{name} must be checked out at {revision}; existing source was preserved.")
    elif (path / "AMETHYST_SOURCE_REVISION").read_text().strip() != revision:
        raise RuntimeError(f"Unexpected {name} source revision.")
    return path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--release-dir", type=Path, default=ROOT.parent / "dist")
    parser.add_argument("--languages", default="en")
    parser.add_argument("--update-lock", action="store_true")
    parser.add_argument("--configfile", type=Path)
    args = parser.parse_args()
    sources = {name: source_tree(name, *spec) for name, spec in SOURCES.items()}
    for name, patches in {"fomod": ["fomod-compat.patch"],
                          "omod": ["omod-net10.patch", "omod-installers.patch", "omod-script-parser.patch"]}.items():
        patch_env = dict(os.environ, GIT_CEILING_DIRECTORIES=str(sources[name].parent))
        for filename in patches:
            patch = ROOT / "patches" / filename
            check = subprocess.run(["git", "apply", "--check", str(patch)], cwd=sources[name], env=patch_env, capture_output=True)
            if check.returncode == 0:
                subprocess.run(["git", "apply", str(patch)], cwd=sources[name], env=patch_env, check=True)
            else:
                subprocess.run(["git", "apply", "--reverse", "--check", str(patch)], cwd=sources[name], env=patch_env, check=True)
    dotnet = os.environ.get("DOTNET", "dotnet")
    project = ROOT / "Amethyst.LegacyInstaller.csproj"
    properties = ["-r", "win-x64", "-p:EnableWindowsTargeting=true", "-p:RuntimeFrameworkVersion=10.0.14",
                  "-p:TargetLatestRuntimePatch=false", "-p:DebugType=None",
                  "-p:SatelliteResourceLanguages=" + args.languages]
    restore = [dotnet, "restore", str(project), *properties]
    if not args.update_lock:
        restore.append("--locked-mode")
    if args.configfile:
        restore += ["--configfile", str(args.configfile.resolve())]
    subprocess.run(restore, cwd=ROOT, check=True)
    with tempfile.TemporaryDirectory(prefix="publish-", dir=ROOT / ".build") as temporary:
        publish = Path(temporary)
        subprocess.run([dotnet, "publish", str(project), "-c", "Release", *properties,
                        "--self-contained", "true", "--no-restore", "-o", str(publish)], cwd=ROOT, check=True)
        for path in publish.rglob("*.pdb"):
            path.unlink()
        collect_notices(ROOT, publish, sources)
        manifest = {
            "version": json.loads((ROOT.parent / "plugin.json").read_text())["version"],
            "sdk": subprocess.check_output([dotnet, "--version"], cwd=ROOT, text=True).strip(),
            "sources": {name: {"url": url, "revision": revision} for name, (url, revision) in SOURCES.items()},
            "files": {str(path.relative_to(publish)): file_hash(path)
                      for path in sorted(publish.rglob("*")) if path.is_file()},
        }
        (publish / "build-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
        destination = ROOT / "publish"
        previous = ROOT / ".build" / "previous-publish"
        if previous.exists():
            raise RuntimeError(f"Preserved previous build exists at {previous}; move it before rebuilding.")
        if destination.exists():
            destination.rename(previous)
        try:
            shutil.copytree(publish, destination)
        except BaseException:
            if destination.exists():
                shutil.rmtree(destination)
            if previous.exists():
                previous.rename(destination)
            raise
        if previous.exists():
            shutil.rmtree(previous)
    create_release(ROOT, args.release_dir.resolve(), sources, SOURCES)


if __name__ == "__main__":
    main()
