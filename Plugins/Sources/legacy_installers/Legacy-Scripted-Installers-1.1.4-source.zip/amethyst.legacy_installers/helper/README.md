# Installer helper

This plugin owns the Windows C# helper, its source and its bundled .NET runtime.
The helper returns generated files, plugin activation requests and INI edits;
the Python plugin connects those requests to the selected Amethyst profile.

To rebuild, install Python 3.11+, the .NET 10 SDK specified in `global.json`,
and Git, then run:

```sh
python helper/build.py
```

Run that command from the plugin folder. Set `DOTNET` to select an SDK executable.
The build downloads the GPL-3.0 Nexus Mods FOMOD engine pinned to
`af3c8355b2e22f1c7c4272c8eb3cb928ccb5f8c1` and OMODFramework 3.0.1 pinned to
`d41af056d268e621f2a03c4191cc6f3958077ed3`. OMODFramework is rebuilt from source
with `patches/omod-net10.patch`: .NET 10 targeting, SharpCompress 0.48.0's API,
exact-length reads, and removal of an unnecessary package reference.
The additional `patches/omod-installers.patch` fixes full-path BSA lookups,
compressed entry reads, generated-file paths, BSA ordering/encoding and the default
file selection for C# OMOD scripts. `patches/fomod-compat.patch` targets the C#
engine at .NET 10, references its WinForms dependencies and exposes pending copy
and generated-file instructions to subsequent script reads.
These modifications were made for Amethyst on 2026-10-27.

The runtime is pinned to .NET 10.0.14. NuGet versions and content hashes are in
`packages.lock.json`; normal builds use locked restore. Use `--update-lock` only
when deliberately updating dependencies. Published files go in `helper/publish/`.
`build-manifest.json` records the SDK, upstream revisions, and SHA-256 file hashes.

The default build retains English and neutral resources and omits PDB symbols.
Use `--languages de`, for example, to retain a different satellite language.
The runtime remains self-contained and untrimmed: WinForms and the runtime C#
compiler require this layout. Single-file publishing is unsuitable without
adapting the compiler's use of on-disk assembly metadata.

The build also creates binary and corresponding-source ZIPs and SHA-256 checksums
in `dist/`. Publish both ZIPs together, with clear access to the matching source.
The source ZIP includes the helper, build scripts, dependency lock, notices, and
the pinned upstream source trees with the compatibility patches applied. It can rebuild
without cloning the GPL dependencies; NuGet restore still needs its package feed
or a populated cache. `--release-dir PATH` selects another output directory.

Do not commit `publish/`, `.build/`, `bin/`, `obj/`, or `dist/` to a source-only
repository. The binary release includes its required DLLs and full notices.
Each dependency retains its own licence; see `publish/THIRD-PARTY-NOTICES.json`
and `publish/licenses/`. The plugin and linked helper are GPL-3.0-only.

Sources and licenses:

- https://github.com/Nexus-Mods/fomod-installer
- https://github.com/erri120/OMODFramework

`AMETHYST_LEGACY_INSTALLER` may select another published helper executable for
development. The normal plugin uses its own `helper/publish/` directory.

Wine prefix templates are cached under
`${XDG_CACHE_HOME:-~/.cache}/AmethystModManager/legacy-installers/`, keyed by the
runner binaries and ntdll identity. Only clean Wine initialisation runs in the
template; every mod installer gets a separate copy, using reflinks when supported.
`AMETHYST_LEGACY_CACHE` overrides the cache location. Removing the cache when no
installer is running forces regeneration. Timing messages separate preparation,
OMOD extraction, and output copying; time spent choosing options is excluded from
the extraction/copy measurements. OMOD workers are capped at four, with sequential
extraction for small packages, CRC validation, and a memory budget capped at 1 GiB.

To create the clean Resources-branch package after building the helper, run:

```sh
python helper/package_resources.py --output /path/to/new-output-directory
```

This creates Plugins/v2/legacy_installers and a matching source ZIP under
Plugins/Sources/legacy_installers. Publish both. Runtime bytes are unchanged;
the user package omits build files and XML API references and stores the runtime
in helper/runtime.zip to remain below the manager store's 64 MiB limit.
The Python plugin verifies and extracts that bundle into a cache on first use.
