﻿using FomodInstaller.Interface;
using FomodInstaller.ModInstaller;
using Microsoft.CSharp.RuntimeBinder;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Dynamic;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ModInstallerIPC
{
    struct Defaults
    {
        public static int TIMEOUT_MS = 5000;
    }

    struct OutMessage
    {
        public string id;
        public object callback;
        public object data;
        public object error;
    }

    public class Helpers
    {
        /**
         * prepare a dynamic object from Json.Net to be passed into the fomod installer such that it
         * can be unpacked correctly
         */
        public static object ValueNormalize(object input)
        {
            if (input == null)
            {
                return null;
            }

            if (input.GetType() == typeof(JValue))
            {
                input = ((JValue)input).Value;
            }

            if (input.GetType() == typeof(JArray))
            {
                dynamic binder = new ArrayBinder((JArray)input);
                return (object[])binder;
            }
            else if (input.GetType() == typeof(JObject))
            {
                IDictionary<string, object> res = ((JObject)input).ToObject<IDictionary<string, object>>();
                if (res.ContainsKey("type") && ((string)res["type"] == "Buffer"))
                {
                    return Convert.FromBase64String((string)res["data"]);
                } else {
                    return new DictWrap(res);
                }
            }
            else if (input.GetType() == typeof(long))
            {
                // rebox System.Int64 to System.Int32 because that's what the installer is
                // expecting and I found no good way to do the cast implicitly as necessary.
                // my C#-fu is just to weak
                return (int)(long)input;
            }
            else
            {
                return input;
            }
        }

        /**
         * dynamic object allowing access to a dictionary through regular object syntax (obj.foobar instead of dict["foobar"]).
         * currently read only
         */
        public class DictWrap : DynamicObject
        {

            private IDictionary<string, object> mWrappee;
            public DictWrap(IDictionary<string, object> dict)
            {
                mWrappee = dict;
            }

            public override bool TryGetMember(GetMemberBinder binder, out object result)
            {
                if (mWrappee.ContainsKey(binder.Name))
                {
                    result = ValueNormalize(mWrappee[binder.Name]);
                    return true;
                }
                else
                {
                    result = null;
                    return false;
                }
            }
        }

        /**
         * Allow a dynamic list type (JArray) to be implicitly converted to an array or any enumerable
         * as needed
         **/
        private class ArrayBinder : DynamicObject
        {
            private readonly JArray mArray;

            public ArrayBinder(JArray arr)
            {
                mArray = arr;
            }

            public override bool TryConvert(ConvertBinder binder, out object result)
            {
                IEnumerable<object> arr = mArray.Select(token => ValueNormalize(token));

                // some kind of array
                if (binder.Type.IsArray)
                {
                    result = arr.ToArray();
                }
                else if (binder.Type.GetMethod("GetEnumerator") != null)
                {
                    result = arr;
                } else
                {
                    result = null;
                }
                return true;
            }
        }
    }

    /**
     * A dynamic object that acts as if it has any function the caller asks for.
     * The function signature can only be "Task<object> func(object arg)" or 
     * "Task<object> func(object[] args)"
     * Any call to that function will be relayed as an ipc to the client and the response returned
     **/
    public class Context : DynamicObject
    {
        private class BindLater : DynamicObject
        {
            private readonly string mName;
            private readonly Func<string, object[], Task<dynamic>> mCallIPC;

            public BindLater(string name, Func<string, object[], Task<dynamic>> callIPC)
            {
                mName = name;
                mCallIPC = callIPC;
            }

            public override bool TryConvert(ConvertBinder binder, out object result)
            {
                if (binder.Type.GenericTypeArguments[0].Name == "Object")
                {
                    // provides only one parameter
                    Func<object, Task<object>> res = args => mCallIPC(mName, new object[] { args });
                    result = res;
                } else
                {
                    // provides multiple parameters
                    Func<object[], Task<object>> res = args => mCallIPC(mName, args);
                    result = res;
                }

                return true;
            }
        }

        private readonly Func<string, object[], Task<dynamic>> mCallIPC;
        public Context(Func<string, object[], Task<object>> callIPC)
        {
            this.mCallIPC = callIPC;
        }

        public override bool TryGetMember(GetMemberBinder binder, out object result)
        {
            result = new BindLater(binder.Name, mCallIPC);
            return true;
        }
    }

    class Server
    {
        /**
         * Turn a proper object into an ExpandoObject
         */
        private static dynamic ToExpando(object value)
        {
            IDictionary<string, object> expando = new ExpandoObject();

            foreach (PropertyDescriptor property in TypeDescriptor.GetProperties(value.GetType()))
            {
                expando.Add(property.Name, property.GetValue(value));
            }

            return expando as ExpandoObject;
        }

        private class DeferContext
        {
            public Context plugin { get; private set; }
            public Context ini { get; private set; }
            public Context context { get; private set; }
            public Context ui { get; private set; }

            public DeferContext(string id, Func<string, string, string, object[], Task<object>> ContextIPC)
            {
                plugin = new Context((string name, object[] args) => ContextIPC(id, "plugin", name, args));
                ini = new Context((string name, object[] args) => ContextIPC(id, "ini", name, args));
                context = new Context((string name, object[] args) => ContextIPC(id, "context", name, args));
                ui = new Context((string name, object[] args) => ContextIPC(id, "ui", name, args));
            }
        }

        /**
         * serializer to be used in conversion to json that converts function into primitive types that can be serialized.
         * The functions are turned into an object like this: { "__callback": "<id>" }
         * The peer can then invoke that callback by sending { "command": "Invoke", data: { "requestId": "<id>", "callbackId": "<id>", "args": [...] } }
         * The requestId is the id of the initial call (TestSupported or Install) the peer initiated the communication with, callbackId is the id
         *   we sent with __callback and args are the parameters to be passed to the callback. It's the peers responsible to pass the correct types
         */
        private class FunctionSerializer : JsonConverter
        {
            public FunctionSerializer()
            {
            }

            public ConcurrentDictionary<string, Delegate> callbacks { get; } = new ConcurrentDictionary<string, Delegate>();

            public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
            {
                Type type = value.GetType();
                System.Func<object, Task<object>> func = (System.Func<object, Task<object>>)value;

                string id = GenerateId();
                callbacks[id] = func;

                JToken t = JToken.FromObject(new { __callback = id });

                t.WriteTo(writer);
            }

            public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
            {
                throw new NotImplementedException("Unnecessary because CanRead is false. The type will skip the converter.");
            }

            public override bool CanRead
            {
                get { return false; }
            }

            public override bool CanConvert(Type objectType)
            {
                var methods = objectType.GetMethods();
                return objectType.GetMethod("DynamicInvoke") != null;
            }
        }

        private class BufferSerializer : JsonConverter
        {
            public BufferSerializer() { }

            public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
            {
                JToken res = JToken.FromObject(new
                {
                    type = "Buffer",
                    data = Convert.ToBase64String((byte[])value),
                });
                res.WriteTo(writer);
            }

            public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
            {
                throw new NotImplementedException("Unnecessary because CanRead is false. The type will skip the converter.");
            }

            public override bool CanRead
            {
                get { return false; }
            }

            public override bool CanConvert(Type objectType)
            {
                return objectType.IsArray && objectType.GetElementType() == typeof(byte);
            }
        }

        private readonly string mId;
        private readonly bool mListen;
        private bool mUsePipe = false;
        private Installer mInstaller;
        private ConcurrentDictionary<string, TaskCompletionSource<object>> mAwaitedReplies;
        private ConcurrentDictionary<string, ConcurrentDictionary<string, Delegate>> mCallbacks;
        private Action<OutMessage> mEnqueue;

        /**
         * listens on a port and handles TestSupported/Install commands to deal with fomod installation
         */
        public Server(string id, bool pipe, bool listen)
        {
            mId = id;
            mListen = listen;
            mUsePipe = pipe;
            mInstaller = new Installer();

            mAwaitedReplies = new ConcurrentDictionary<string, TaskCompletionSource<object>>();
            mCallbacks = new ConcurrentDictionary<string, ConcurrentDictionary<string, Delegate>>();
        }

        public void HandleMessages()
        {
            var enc = new UTF8Encoding(false);
            Stream streamIn = null;
            Stream streamOut = null;
            TcpClient client = null;
            NamedPipeClientStream pipeIn = null;
            NamedPipeClientStream pipeOut = null;
            BlockingCollection<OutMessage> outgoing = null;
            CancellationTokenSource cancelSignal = null;

            try
            {
                if (mUsePipe) {
                    Console.Out.WriteLine("[C#] Creating inbound pipe client for: " + mId);
                    Console.Out.Flush();
                    pipeIn = new NamedPipeClientStream(".", mId, PipeDirection.In);
                    Console.Out.WriteLine("[C#] Inbound pipe created, connecting...");
                    Console.Out.Flush();
                    pipeIn.Connect(30000);
                    Console.Out.WriteLine("[C#] Inbound pipe connected successfully");
                    Console.Out.Flush();

                    // In an appcontainer we can't host the pipe,
                    // in a low integrity process we can't create a client stream with direction out.

                    Console.Out.WriteLine("[C#] Creating outbound pipe client for: " + mId + "_reply");
                    Console.Out.Flush();
                    pipeOut = new NamedPipeClientStream(".", mId + "_reply", PipeDirection.Out);
                    Console.Out.WriteLine("[C#] Outbound pipe created, connecting...");
                    Console.Out.Flush();
                    pipeOut.Connect(30000);
                    Console.Out.WriteLine("[C#] Outbound pipe connected successfully");
                    Console.Out.Flush();

                    streamIn = pipeIn;
                    streamOut = pipeOut;

                    Console.Out.WriteLine("[C#] Both pipes connected, writing handshake...");
                    Console.Out.Flush();
                } else
                {
                    // use a single network socket
                    client = new TcpClient();
                    try
                    {
                        client.Connect("localhost", Int32.Parse(mId));
                    } catch (Exception e)
                    {
                        Console.Error.WriteLine("failed to connect to local port {0}: {1}", mId, e.Message);
                        throw;
                    }
                    NetworkStream stream = client.GetStream();
                    streamIn = streamOut = stream;
                }
                // writer.AutoFlush = true;

                // a queue where dequeuing blocks while the queue is empty
                outgoing = new BlockingCollection<OutMessage>();

                mEnqueue = msg => outgoing.Add(msg);

                Console.Out.WriteLine("[C#] Writing handshake 'connected'...");
                Console.Out.Flush();
                byte[] input = "connected"u8.ToArray();
                streamOut.Write(input, 0, input.Length);
                streamOut.Flush();
                Console.Out.WriteLine("[C#] Handshake written and flushed");
                Console.Out.Flush();

                cancelSignal = new CancellationTokenSource();

                Exception cancelEx = null;

                Console.Out.WriteLine("[C#] Starting reader/writer tasks...");
                Console.Out.Flush();

                Task readerTask = Task.Run(() => {
                    Thread.CurrentThread.Name = "reader loop";
                    Console.Out.WriteLine("[C#] Reader task started");
                    Console.Out.Flush();
                    try
                    {
                        ReaderLoop(streamIn, mEnqueue);
                        Console.Out.WriteLine("[C#] Reader loop exited normally");
                        Console.Out.Flush();
                        outgoing.CompleteAdding();
                    }
                    catch (Exception e)
                    {
                        Console.Error.WriteLine("[C#] Read loop failed: {0}\n{1}", e.Message, e.StackTrace);
                        Console.Error.Flush();
                        cancelSignal.Cancel();
                        cancelEx = e;
                    };
                });
                Task writerTask = Task.Run(() => {
                    Thread.CurrentThread.Name = "writer loop";
                    Console.Out.WriteLine("[C#] Writer task started");
                    Console.Out.Flush();
                    try
                    {
                        WriterLoop(streamOut, outgoing);
                        Console.Out.WriteLine("[C#] Writer loop exited normally");
                        Console.Out.Flush();
                    }
                    catch (Exception e)
                    {
                        Console.Error.WriteLine("[C#] Write loop failed: {0}\n{1}", e.Message, e.StackTrace);
                        Console.Error.Flush();
                        cancelSignal.Cancel();
                        cancelEx = e;
                    }
                });

                Console.Out.WriteLine("[C#] Waiting for reader/writer tasks to complete...");
                Console.Out.Flush();

                // run until either reader or writer signal for termination
                try
                {
                    Task.WaitAll(new Task[] { readerTask, writerTask }, cancelSignal.Token);
                    Console.Out.WriteLine("[C#] Tasks completed normally");
                    Console.Out.Flush();
                } catch (Exception err)
                {
                    throw cancelEx ?? err;
                }
            }
            finally
            {
                // Proper cleanup of all resources
                try
                {
                    CleanupAwaitedReplies();

                    cancelSignal?.Dispose();
                    outgoing?.Dispose();

                    // Close streams
                    if (streamIn != streamOut)
                    {
                        streamIn?.Close();
                        streamOut?.Close();
                    }
                    else
                    {
                        streamIn?.Close();
                    }

                    // Dispose pipes
                    pipeIn?.Dispose();
                    pipeOut?.Dispose();

                    // Close TCP client
                    client?.Close();
                }
                catch (Exception ex)
                {
                    Console.Error.WriteLine("Error during cleanup: {0}", ex.Message);
                }
            }
        }

        private void CleanupAwaitedReplies()
        {
            // Cancel any pending awaited replies to prevent hanging
            foreach (var reply in mAwaitedReplies.Values)
            {
                if (!reply.Task.IsCompleted)
                {
                    reply.SetCanceled();
                }
            }
            mAwaitedReplies.Clear();
        }

        private void ReaderLoop(Stream stream, Action<OutMessage> onSend)
        {
            Console.Out.WriteLine("[C#] ReaderLoop: entering loop, waiting for data...");
            Console.Out.Flush();

            bool running = true;

            int bufferSize = 64 * 1024;
            int offset = 0;
            byte[] buffer = new byte[bufferSize];

            // this handles all messages from the client
            while (running)
            {
                int left = bufferSize - offset;

                Console.Out.WriteLine("[C#] ReaderLoop: calling stream.Read()...");
                Console.Out.Flush();
                // int numRead = reader.Read(buffer, offset, left);
                int numRead = stream.Read(buffer, offset, left);
                Console.Out.WriteLine("[C#] ReaderLoop: stream.Read() returned " + numRead + " bytes");
                Console.Out.Flush();
                if (numRead == 0)
                {
                    Console.Out.WriteLine("[C#] ReaderLoop: received 0 bytes, exiting loop");
                    Console.Out.Flush();
                    running = false;
                }
                else if (numRead == left)
                {
                    // buffer too small, double it
                    bufferSize = bufferSize * 2;
                    byte[] newBuffer = new byte[bufferSize];
                    Array.Copy(buffer, newBuffer, buffer.Length);
                    offset = buffer.Length;
                    buffer = newBuffer;
                }
                else
                {
                    var input = System.Text.Encoding.UTF8.GetString(buffer, 0, numRead + offset);
                    // var input = new string(buffer, 0, numRead + offset);
                    offset = 0;

                    foreach (var msg in input.Split('\uFFFF'))
                    {
                        if (msg.Length == 0)
                        {
                            continue;
                        }

                        OnReceived(msg).ContinueWith(reply =>
                        {
                            onSend(reply.Result);
                        });
                    }
                }
            }
        }

        private void WriterLoop(Stream writer, BlockingCollection<OutMessage> outgoing)
        {
            try
            {
                while (!outgoing.IsCompleted)
                {
                    OutMessage msg;
                    if (outgoing.TryTake(out msg, 100))
                    {
                        SendResponse(writer, msg);
                    }
                }
            }
            catch (InvalidOperationException)
            {
                // queue was closed by the producer
                return;
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine("WriterLoop error: {0}", ex.Message);
                throw;
            }
        }

        private static string GenerateId()
        {
            return Guid.NewGuid().ToString("N");
        }

        private Task<object> ContextIPC(string targetId, string targetType, string name, object[] args)
        {
            string id = GenerateId();

            Task<object> result = AwaitReply(id);

            try
            {
                mEnqueue(new OutMessage
                {
                    id = id,
                    callback = new { id = targetId, type = targetType },
                    data = new { name, args }
                });
            } catch (Exception e)
            {
                Console.Error.WriteLine("Failed to enqueue message: {0}", e.Message);
            }

            return result;
        }

        private Task<object> AwaitReply(string id)
        {
            var repliesCompletion = new TaskCompletionSource<object>();
            if (!mAwaitedReplies.TryAdd(id, repliesCompletion))
            {
                return Task.FromException<object>(new ArgumentException("Key already exists", id));
            }
            return repliesCompletion.Task;
        }

        private void SendResponse(Stream writer, OutMessage resp)
        {
            try
            {
                FunctionSerializer funcSer = new FunctionSerializer();
                BufferSerializer buffSer = new BufferSerializer();
                string serialized = JsonConvert.SerializeObject(new { resp.id, resp.callback, resp.data, resp.error }, funcSer, buffSer);
                mCallbacks[resp.id] = funcSer.callbacks;
                var input = System.Text.Encoding.UTF8.GetBytes(serialized + "\uFFFF");

                writer.Write(input, 0, input.Length);
                writer.Flush();
            }
            catch (Exception ex)
            {
                Console.Error.WriteLine("Failed to send response for message {0}: {1}", resp.id, ex.Message);
                throw; // Re-throw to let WriterLoop handle the failure properly
            }
        }

        private async Task<object> DispatchTestSupported(JObject data)
        {
            var files = new List<string>(data["files"].Children().ToList()
                .Select(input => input.ToString()));

            var allowedTypes = new List<string>(data["allowedTypes"].Children().ToList()
                .Select(input => input.ToString()));

            Dictionary<string, object> result = await mInstaller.TestSupported(files, allowedTypes);
            return result;
        }

        private async Task<object> DispatchInstall(string id, JObject data)
        {
            var files = new List<string>(data["files"].Children().ToList().Select(input => input.ToString()));
            var stopPatterns = new List<string>(data["stopPatterns"].Children().ToList().Select(input => input.ToString()));
            var pluginPath = data["pluginPath"].ToString();
            var scriptPath = data["scriptPath"].ToString();
            bool validate = true;
            JToken val;
            if (data.TryGetValue("validate", out val))
            {
                validate = val.ToObject<bool>();
            }

            dynamic choices;
            try
            {
                choices = data["fomodChoices"];
            }
            catch (RuntimeBinderException) {
                choices = null;
            }

            DeferContext context = new DeferContext(id, (targetId, targetType, name, args) => ContextIPC(targetId, targetType, name, args));
            CoreDelegates coreDelegates = new DynamicCoreDelegates(ToExpando(context));

            return await mInstaller.Install(files, stopPatterns, pluginPath, scriptPath, choices, false, validate, (ProgressDelegate)((int progress) => { }), coreDelegates);
        }

        private async Task<object> DispatchInvoke(JObject data)
        {
            string requestId = data["requestId"].ToString();
            string callbackId = data["callbackId"].ToString();
            var argsList = data["args"].ToList();
            dynamic[] args = data["args"].ToList().Select(input => Helpers.ValueNormalize(input)).ToArray();
            if (args.Length == 0)
            {
                args = new object[] { null };
            }
            object res = mCallbacks[requestId][callbackId].DynamicInvoke(args);
            return await (Task<object>)res;
        }

        private void DispatchReply(dynamic data)
        {
            string id = data.request.id;
            if (!mAwaitedReplies.ContainsKey(id))
            {
                // not waiting for this (any more)? Might have been a timeout
                return;
            }
            if (data.error != null)
            {
                mAwaitedReplies[id].SetException(new Exception(data.error.message.ToString()));
            }
            else
            {
                try
                {
                    mAwaitedReplies[id].SetResult(Helpers.ValueNormalize(data.data));
                } catch (RuntimeBinderException)
                {
                    mAwaitedReplies[id].SetException(new Exception(String.Format("No data and no error field in {0}", data.ToString())));
                }
            }
        }

        private async Task<object> Dispatch(string id, JObject data)
        {
            if (mAwaitedReplies.ContainsKey(id))
            {
                mAwaitedReplies[id].SetResult(data);
            }
            string command = data["command"].ToString();
            switch (command)
            {
                case "TestSupported": return await DispatchTestSupported(data);
                case "Install": return await DispatchInstall(id, data);
                case "Invoke": return await DispatchInvoke(data);
                case "Reply":
                    {
                        DispatchReply(data);
                        return null;
                    }
                case "Quit":
                    {
                        // don't think we need to do anything, this shuts down cleanly when the peer closes the socket
                        return "";
                    }
            }
            return "";
        }

        private async Task<OutMessage> OnReceived(string data)
        {
            JObject invocation;
            try
            {
                invocation = JObject.Parse(data);
            } catch (Exception e)
            {
                Console.Error.WriteLine("Failed to parse json (error: {0}): {1}", e.Message, data);
                return await Task.Run(() =>
                {
                    return new OutMessage { id = "parseerror", error = new { name = "ParseError", message = e.Message, stack = e.StackTrace } };
                });
            }
            string id = invocation["id"].ToString();
            return await Task.Run(async () =>
            {
                try
                {
                    return new OutMessage { id = id, data = await Dispatch(id, (JObject)invocation["payload"]) };
                }
                catch (Exception e)
                {
                    Exception err = e;
                    string message = e.Message;

                    while (err.InnerException != null)
                    {
                        err = err.InnerException;
                        message += "; " + err.Message;
                    }
                    return new OutMessage {
                        id = id,
                        error = new {
                            name = e.GetType().FullName,
                            message = message,
                            stack = e.StackTrace,
                            data = e.Data,
                        }
                    };
                }
            });
        }
    }
}
