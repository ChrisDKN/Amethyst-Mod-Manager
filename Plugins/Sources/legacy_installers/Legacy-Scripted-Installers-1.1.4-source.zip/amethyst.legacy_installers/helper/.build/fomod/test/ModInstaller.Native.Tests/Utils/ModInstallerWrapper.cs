﻿using BUTR.NativeAOT.Shared;

using FomodInstaller.Interface.ui;

using ModInstaller.Native.Tests.Utils;

using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

using TestData;

namespace ModInstaller.Native.Tests;

public sealed class ModInstallerWrapper
{

    private readonly InstallData _data;
    private readonly List<SelectedOption>? _dialogChoices;
    private readonly bool _unattended;

    private unsafe param_ptr* _callback_handler;
    private unsafe delegate* unmanaged[Cdecl]<param_ptr*, param_int, param_int, param_json*, return_value_void*, void> _select;
    private unsafe delegate* unmanaged[Cdecl]<param_ptr*, param_bool, param_int, return_value_void*, void> _cont;
    private unsafe delegate* unmanaged[Cdecl]<param_ptr*, return_value_void*, void> _cancel;

    private InstallerStep[]? _installerSteps;
    private int? _currentStep;

    public ModInstallerWrapper(InstallData data)
    {
        _data = data;
        _dialogChoices = _data.DialogChoices?.ToList();
        _unattended = _data.DialogChoices == null;
    }

    private static unsafe byte* Copy(in ReadOnlySpan<byte> data, bool isOwner)
    {
        var dst = (byte*) Allocator.Alloc((uint) data.Length);
        data.CopyTo(new Span<byte>(dst, data.Length));
        return dst;
    }

    [UnmanagedCallersOnly(CallConvs = [typeof(CallConvCdecl)])]
    public static unsafe return_value_data* ReadFileContent(param_ptr* handler, param_string* pFilePath, param_int offset, param_int length)
    {
        Stream? stream = null;
        try
        {
            var filePath = new string(param_string.ToSpan(pFilePath));

            var modInstallerWrapper = (ModInstallerWrapper) GCHandle.FromIntPtr((IntPtr) handler).Target!;
            var entry = modInstallerWrapper._data.ModArchive.Entries.FirstOrDefault(x => x.GetNormalizedName() == filePath);
            if (entry == null)
                return return_value_data.AsValue(null, 0, false);

            stream = entry.OpenEntryStream();

            if (length == -1) length = (int) entry.Size;

            if (length == 0)
            {
                return return_value_data.AsValue(Copy([], false), 0, false);
            }

            if (offset > 0)
            {
                var discard = new byte[offset];
                stream.ReadExactly(discard);
            }

            var bufferPtr = (byte*) Allocator.Alloc((uint) (int) length);
            var buffer = new Span<byte>(bufferPtr, length);
            stream.ReadExactly(buffer);
            return return_value_data.AsValue(bufferPtr, length, false);
        }
        catch (Exception e)
        {
            return return_value_data.AsException(e, false);
        }
        finally
        {
            stream?.Dispose();
        }
    }

    [UnmanagedCallersOnly(CallConvs = [typeof(CallConvCdecl)])]
    public static unsafe return_value_json* ReadDirectoryFileList(param_ptr* handler, param_string* pDirectoryPath, param_string* pPattern, param_int searchOption)
    {
        try
        {
            var directoryPath = new string(param_string.ToSpan(pDirectoryPath));
            var pattern = new string(param_string.ToSpan(pPattern));

            var modInstallerWrapper = (ModInstallerWrapper) GCHandle.FromIntPtr((IntPtr) handler).Target!;
            
            var filesInFolder = modInstallerWrapper._data.ModArchive.Entries
                .Where(x => !x.IsDirectory && x.GetNormalizedName()?.StartsWith(directoryPath, StringComparison.OrdinalIgnoreCase) == true)
                .Select(x => x.GetNormalizedName())
                // TODO: Do something with pattern and searchOption
                .ToArray();

            return return_value_json.AsValue(filesInFolder, Utils2.CustomSourceGenerationContext.StringArray, false);
        }
        catch (Exception e)
        {
            return return_value_json.AsException(e, false);
        }
    }

    [UnmanagedCallersOnly(CallConvs = [typeof(CallConvCdecl)])]
    public static unsafe return_value_json* ReadDirectoryList(param_ptr* handler, param_string* pDirectoryPath)
    {
        try
        {
            var directoryPath = new string(param_string.ToSpan(pDirectoryPath));
            
            var modInstallerWrapper = (ModInstallerWrapper) GCHandle.FromIntPtr((IntPtr) handler).Target!;
           
            var foldersInFolder = modInstallerWrapper._data.ModArchive.Entries
                .Where(x => x.IsDirectory && x.GetNormalizedName()?.StartsWith(directoryPath, StringComparison.OrdinalIgnoreCase) == true)
                .Select(x => x.GetNormalizedName())
                // TODO: Do something with pattern and searchOption
                .ToArray();

            return return_value_json.AsValue(foldersInFolder, Utils2.CustomSourceGenerationContext.StringArray, false);
        }
        catch (Exception e)
        {
            return return_value_json.AsException(e, false);
        }
    }

    [UnmanagedCallersOnly(CallConvs = [typeof(CallConvCdecl)])]
    public static unsafe return_value_json* PluginsGetAll(param_ptr* handler, param_bool includeDisabled)
    {
        try
        {
            var modInstallerWrapper = (ModInstallerWrapper) GCHandle.FromIntPtr((IntPtr) handler).Target!;
            return return_value_json.AsValue(modInstallerWrapper._data.InstalledPlugins, Utils2.CustomSourceGenerationContext.ListString, false);
        }
        catch (Exception e)
        {
            return return_value_json.AsException(e, false);
        }
    }

    [UnmanagedCallersOnly(CallConvs = [typeof(CallConvCdecl)])]
    public static unsafe return_value_string* ContextGetAppVersion(param_ptr* handler)
    {
        try
        {
            var modInstallerWrapper = (ModInstallerWrapper) GCHandle.FromIntPtr((IntPtr) handler).Target!;
            return return_value_string.AsValue(BUTR.NativeAOT.Shared.Utils.Copy(modInstallerWrapper._data.AppVersion, false), false);
        }
        catch (Exception e)
        {
            return return_value_string.AsException(e, false);
        }
    }

    [UnmanagedCallersOnly(CallConvs = [typeof(CallConvCdecl)])]
    public static unsafe return_value_string* ContextGetCurrentGameVersion(param_ptr* handler)
    {
        try
        {
            var modInstallerWrapper = (ModInstallerWrapper) GCHandle.FromIntPtr((IntPtr) handler).Target!;
            return return_value_string.AsValue(BUTR.NativeAOT.Shared.Utils.Copy(modInstallerWrapper._data.GameVersion, false), false);
        }
        catch (Exception e)
        {
            return return_value_string.AsException(e, false);
        }
    }

    [UnmanagedCallersOnly(CallConvs = [typeof(CallConvCdecl)])]
    public static unsafe return_value_string* ContextGetExtenderVersion(param_ptr* handler, param_string* p_extender_name)
    {
        try
        {
            var modInstallerWrapper = (ModInstallerWrapper) GCHandle.FromIntPtr((IntPtr) handler).Target!;
            return return_value_string.AsValue(BUTR.NativeAOT.Shared.Utils.Copy(modInstallerWrapper._data.ExtenderVersion, false), false);
        }
        catch (Exception e)
        {
            return return_value_string.AsException(e, false);
        }
    }

    [UnmanagedCallersOnly(CallConvs = [typeof(CallConvCdecl)])]
    public static unsafe return_value_void* UiStartDialog(
        param_ptr* handler,
        param_string* p_module_name,
        param_json* p_image,
        param_ptr* p_context,
        delegate* unmanaged[Cdecl]<param_ptr*, param_int, param_int, param_json*, return_value_void*, void> p_select_callback,
        delegate* unmanaged[Cdecl]<param_ptr*, param_bool, param_int, return_value_void*, void> p_cont_callback,
        delegate* unmanaged[Cdecl]<param_ptr*, return_value_void*, void> p_cancel_callback)
    {
        try
        {
            var modInstallerWrapper = (ModInstallerWrapper) GCHandle.FromIntPtr((IntPtr) handler).Target!;

            modInstallerWrapper._callback_handler = p_context;
            modInstallerWrapper._select = p_select_callback;
            modInstallerWrapper._cont = p_cont_callback;
            modInstallerWrapper._cancel = p_cancel_callback;

            return return_value_void.AsValue(false);
        }
        catch (Exception e)
        {
            return return_value_void.AsException(e, false);
        }
    }

    [UnmanagedCallersOnly(CallConvs = [typeof(CallConvCdecl)])]
    public static unsafe return_value_void* UiEndDialog(
        param_ptr* handler)
    {
        try
        {
            var modInstallerWrapper = (ModInstallerWrapper) GCHandle.FromIntPtr((IntPtr) handler).Target!;

            modInstallerWrapper._callback_handler = null!;
            modInstallerWrapper._select = null!;
            modInstallerWrapper._cont = null!;
            modInstallerWrapper._cancel = null!;

            modInstallerWrapper._installerSteps = null!;
            modInstallerWrapper._currentStep = 0;

            return return_value_void.AsValue(false);
        }
        catch (Exception e)
        {
            return return_value_void.AsException(e, false);
        }
    }

    private bool dialogInProgress = false;
    [UnmanagedCallersOnly(CallConvs = [typeof(CallConvCdecl)])]
    public static unsafe return_value_void* UiUpdateState(
        param_ptr* handler,
        param_json* p_install_steps,
        param_int current_step)
    {
        try
        {
            var modInstallerWrapper = (ModInstallerWrapper) GCHandle.FromIntPtr((IntPtr) handler).Target!;

            var installSteps = BUTR.NativeAOT.Shared.Utils.DeserializeJson(p_install_steps, SourceGenerationContext.Default.InstallerStepArray);
            var currentStepValue = (int) current_step;

            modInstallerWrapper._installerSteps = installSteps;
            modInstallerWrapper._currentStep = currentStepValue;

            if (modInstallerWrapper.dialogInProgress)
            {
                return return_value_void.AsValue(false);
            }

            if (modInstallerWrapper._callback_handler is null)
                throw new NotSupportedException();

            if (modInstallerWrapper._unattended)
            {
                if (modInstallerWrapper._cont is null)
                    throw new NotSupportedException();

                modInstallerWrapper._cont(modInstallerWrapper._callback_handler, true, currentStepValue, return_value_void.AsValue(false));
            }
            else if (modInstallerWrapper._dialogChoices is { Count: > 0 })
            {
                var option = modInstallerWrapper._dialogChoices.FirstOrDefault(x => x.StepId == currentStepValue);

                using var pluginIds = Utils2.ToJson(option.PluginIds);
                modInstallerWrapper.dialogInProgress = true;
                modInstallerWrapper._select(modInstallerWrapper._callback_handler, option.StepId, option.GroupId, pluginIds, return_value_void.AsValue(false));

                modInstallerWrapper._cont(modInstallerWrapper._callback_handler, true, currentStepValue, return_value_void.AsValue(false));
                modInstallerWrapper.dialogInProgress = false;
            }

            return return_value_void.AsValue(false);
        }
        catch (Exception e)
        {
            return return_value_void.AsException(e, false);
        }
    }
}