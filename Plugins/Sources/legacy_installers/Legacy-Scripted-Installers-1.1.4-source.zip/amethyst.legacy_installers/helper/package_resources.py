import argparse
import hashlib
import json
from pathlib import Path
import shutil
import zipfile


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    source = Path(__file__).resolve().parent.parent
    output = args.output.resolve()
    if output.is_relative_to(source):
        raise ValueError('Choose an output directory outside the plugin source tree.')
    manifest = json.loads((source / 'plugin.json').read_text())
    version = manifest['version']
    publish = source / 'helper/publish'
    build = json.loads((publish / 'build-manifest.json').read_text())
    for name, expected in build['files'].items():
        if digest(publish / name) != expected:
            raise ValueError('Published file failed verification: ' + name)
    output.mkdir(parents=True, exist_ok=False)
    plugin = output / 'Plugins/v2/legacy_installers'
    plugin.mkdir(parents=True)
    for name in ('plugin.json', 'installer.py', 'runtime.py', 'README.md', 'LICENSE', 'NOTICE'):
        shutil.copy2(source / name, plugin / name)
    shutil.copytree(publish / 'licenses', plugin / 'licenses')
    for name in ('THIRD-PARTY-NOTICES.json', 'THIRD-PARTY-NOTICES.txt'):
        shutil.copy2(publish / name, plugin / name)
    runtime = plugin / 'helper/runtime.zip'
    runtime.parent.mkdir()
    kept = {}
    with zipfile.ZipFile(runtime, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(publish.rglob('*')):
            relative = path.relative_to(publish)
            if (not path.is_file() or relative.parts[0] == 'licenses'
                    or path.name.startswith('THIRD-PARTY-NOTICES')
                    or path.name == 'build-manifest.json' or path.suffix in ('.xml', '.pdb')):
                continue
            archive.write(path, relative.as_posix())
            kept[relative.as_posix()] = digest(path)
        archive.writestr('build-manifest.json', json.dumps({**build, 'files': kept,
            'packaging': 'Compressed runtime; licenses and notices are in the plugin root.'}, indent=2) + '\n')
    sizes = [p.stat().st_size for p in plugin.rglob('*') if p.is_file()]
    if len(sizes) > 1024 or sum(sizes) > 64 * 1024 * 1024:
        raise ValueError('The plugin exceeds the manager store package limits.')
    sources = output / 'Plugins/Sources/legacy_installers'
    sources.mkdir(parents=True)
    source_zip = sources / f'Legacy-Scripted-Installers-{version}-source.zip'
    with zipfile.ZipFile(source_zip, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(source.rglob('*')):
            relative = path.relative_to(source)
            if (not path.is_file() or set(relative.parts) & {'.git', 'bin', 'obj', '__pycache__', 'dist'}
                    or relative.parts[:2] == ('helper', 'publish')):
                continue
            archive.write(path, str(Path('amethyst.legacy_installers') / relative))
    (output / 'PUBLISHING.md').write_text(
        f'# Legacy Scripted Installers {version}\n\n'
        'Copy the included Plugins tree into the Resources branch, preserving its layout.\n'
        'Plugins/v2/legacy_installers is the user plugin; Plugins/Sources/legacy_installers\n'
        'contains its matching GPL source download, linked from the plugin README.\n'
        'Publish both directories together. PUBLISHING.md and SHA256SUMS are local handoff notes.\n\n'
        'The runtime stays compressed to fit the plugin store limit. It is unpacked and verified\n'
        'in the user cache on first use. No additional .NET download is required.\n'
        'Developer files, build tools, XML API documentation and caches are absent from the user plugin.\n'
        'Required DLLs and dependency license notices are retained.\n')
    (output / 'SHA256SUMS').write_text(''.join(
        f'{digest(p)}  {p.relative_to(output).as_posix()}\n'
        for p in sorted(output.rglob('*')) if p.is_file() and p.name != 'SHA256SUMS'))
    print(f'User plugin: {sum(sizes) / 1024**2:.2f} MiB, {len(sizes)} files')
    print(f'Matching source: {source_zip.stat().st_size / 1024**2:.2f} MiB')
    print(output)


if __name__ == '__main__':
    main()
