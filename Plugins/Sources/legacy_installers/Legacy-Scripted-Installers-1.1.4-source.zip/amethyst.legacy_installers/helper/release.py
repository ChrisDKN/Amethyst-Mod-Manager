import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile


def file_hash(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def collect_notices(root, publish, sources):
    assets = json.loads((root / "obj/project.assets.json").read_text())
    folders = list(map(Path, assets["packageFolders"]))
    notices = publish / "licenses"
    shutil.copytree(root / "licenses", notices)
    entries = []
    overrides = {
        "crc32.net": "Crc32.NET.LICENSE.txt", "k4os.compression.lz4": "K4os.Compression.LZ4.LICENSE.txt",
        "k4os.compression.lz4.streams": "K4os.Compression.LZ4.LICENSE.txt",
        "k4os.hash.xxhash": "K4os.Hash.xxHash.LICENSE.txt", "nlog": "NLog.LICENSE.txt",
        "sharpcompress": "SharpCompress.LICENSE.txt", "omodframework": "OMODFramework.LICENSE.txt",
        "omodframework.scripting": "OMODFramework.LICENSE.txt",
        "microsoft.codeanalysis.common": "Roslyn.LICENSE.txt", "microsoft.codeanalysis.csharp": "Roslyn.LICENSE.txt",
    }
    deps = json.loads((publish / "Amethyst.LegacyInstaller.deps.json").read_text())
    for name, library in sorted(deps["libraries"].items()):
        if library["type"] == "project":
            continue
        package = name.removeprefix("runtimepack.").lower()
        folder = next((base / package for base in folders if (base / package).is_dir()), None)
        if folder is None:
            raise RuntimeError(f"Missing package provenance for {name}")
        metadata = ET.parse(next(folder.glob("*.nuspec"))).getroot().find("{*}metadata")
        fields = {item.tag.split("}")[-1]: item.text for item in metadata}
        record = {"package": name, "authors": fields.get("authors"), "copyright": fields.get("copyright"),
                  "license": fields.get("license"), "project": fields.get("projectUrl"), "notices": []}
        if not record["license"] and package.split("/")[0] in overrides:
            record["license"] = "BSD-3-Clause" if package.startswith("nlog/") else "MIT"
        repository = metadata.find("{*}repository")
        if repository is not None:
            record["repository"] = repository.attrib
        package_notices = notices / package.replace("/", "-")
        for path in folder.rglob("*"):
            if path.is_file() and (path.name.lower().startswith(("license", "third-party", "thirdparty", "notice"))
                                   or package.startswith("sharpcompress/") and path.name.lower() == "readme.md"):
                package_notices.mkdir(exist_ok=True)
                destination = package_notices / str(path.relative_to(folder)).replace("/", "_")
                shutil.copyfile(path, destination)
                record["notices"].append(str(destination.relative_to(publish)))
        override = overrides.get(package.split("/")[0])
        if override:
            record["notices"].append("licenses/" + override)
        if not record["notices"]:
            raise RuntimeError(f"No audited licence notice for {name}")
        entries.append(record)
    shutil.copyfile(sources["fomod"] / "LICENSE.md", notices / "FomodInstaller.LICENSE.txt")
    shutil.copyfile(sources["omod"] / "LICENSE", notices / "OMODFramework.LICENSE.txt")
    (publish / "THIRD-PARTY-NOTICES.json").write_text(json.dumps(entries, indent=2) + "\n")
    (publish / "THIRD-PARTY-NOTICES.txt").write_text(
        "This helper links GPL-3.0-only FOMOD and OMODFramework components.\n"
        "See LICENSE in the plugin root and the corresponding source archive supplied alongside each release.\n"
        "Runtime and third-party components retain their own licences; full notices are in licenses/.\n\n" +
        "\n\n".join(f"{entry['package']}\nAuthors: {entry['authors']}\nCopyright: {entry['copyright']}\n" +
                       "\n".join(entry["notices"]) for entry in entries) + "\n")


def create_release(root, destination, sources, revisions):
    plugin = root.parent
    version = json.loads((plugin / "plugin.json").read_text())["version"]
    destination.mkdir(parents=True, exist_ok=True)
    archives = [destination / f"Legacy-Scripted-Installers-{version}{suffix}.zip" for suffix in ("", "-source")]
    for index, archive in enumerate(archives):
        with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as output:
            for path in sorted(plugin.rglob("*")):
                relative = path.relative_to(plugin)
                if not path.is_file() or set(relative.parts) & {".git", ".build", "bin", "obj", "__pycache__", "dist"}:
                    continue
                if index == 1 and relative.parts[:2] == ("helper", "publish"):
                    continue
                output.write(path, str(Path(plugin.name) / relative))
            if index == 1:
                for name, source in sources.items():
                    prefix = Path(plugin.name) / "helper/.build" / name
                    if (source / ".git").exists():
                        names = subprocess.check_output(["git", "ls-files", "-z"], cwd=source).decode().split("\0")
                        for filename in filter(None, names):
                            path = source / filename
                            if path.is_file():
                                output.write(path, str(prefix / filename))
                    else:
                        for path in sorted(source.rglob("*")):
                            if (path.is_file() and path.name != "AMETHYST_SOURCE_REVISION"
                                    and not set(path.relative_to(source).parts) & {"bin", "obj", ".git"}):
                                output.write(path, str(prefix / path.relative_to(source)))
                    output.writestr(str(prefix / "AMETHYST_SOURCE_REVISION"), revisions[name][1] + "\n")
    (destination / f"Legacy-Scripted-Installers-{version}-SHA256SUMS.txt").write_text(
        "".join(f"{file_hash(path)}  {path.name}\n" for path in archives))
    for archive in archives:
        print(archive)
